# Prediction-using-Decision-Tree-Algorithm
Create the Decision Tree classifier and visualize it graphically.   The purpose is if we feed any new data to this classifier, it would be able to  predict the right class accordingly.    
Watch Tutorial from here https://youtu.be/CBCfOTePVPo  
Dataset : https://bit.ly/3kXTdox 
